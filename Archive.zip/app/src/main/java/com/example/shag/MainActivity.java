package com.example.shag;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {

    // Declare the image views globally to avoid repeated calls to findViewById
    private ImageView homeImg, moneyImg, settingImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragement_container, new Home()).commit();
        }

        // Set up the window insets to adjust padding for system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize buttons and image views
        LinearLayout home = findViewById(R.id.homeBtn);
        LinearLayout money = findViewById(R.id.btnMoney);
        LinearLayout setting = findViewById(R.id.btnSetting);
        homeImg = findViewById(R.id.homeImg);
        moneyImg = findViewById(R.id.moneyImg);
        settingImg = findViewById(R.id.settingImg);

        // Set click listeners for each button
        home.setOnClickListener(view -> loadFragment(new Home(), homeImg));
        money.setOnClickListener(view -> loadFragment(new Money(), moneyImg));
        setting.setOnClickListener(view -> loadFragment(new Settings(), settingImg));
    }

    // Load the fragment and set the appropriate color for the clicked image
    void loadFragment(Fragment fragment, ImageView clickedImg) {
        // Reset all images to white color
        resetImageColor(homeImg);
        resetImageColor(moneyImg);
        resetImageColor(settingImg);

        // Set the clicked image to orange color
        clickedImg.setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.orange), PorterDuff.Mode.SRC_IN);

        // Replace the fragment in the container
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragement_container, fragment)
                .commit();
    }

    // Helper method to reset the image color to white
    private void resetImageColor(ImageView img) {
        img.setColorFilter(ContextCompat.getColor(getApplicationContext(), android.R.color.black), PorterDuff.Mode.SRC_IN);
    }
}
